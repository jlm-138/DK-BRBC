



%% 

function [EXPERT_DRIVEN_RULE ,expert_driven_wt,AA_AC,WTf_AC] = FZ_active_learn_expert( AA,KK,sigmaf,WTf,Ini_e,men,top_k,E_belief_rule,E_Wt,NeedData,Test_Data)

%%      2022----四

% 2022.1.3
%    在这种方法中，   直接采用主动学习的策略进行学习

%   首先将  数据驱动的  取过来   对未标注的进行标注

    AA;  % 从数据处学到的规则前提
    WTf;   % 从数据处学到的规则结论
    KK   ;  %  假定的剩余未标注样本

    E_belief_rule;   % 专家知识前提
    E_Wt  ;   %  专家知识部分结论

    AA_AC  =  AA;
    WTf_AC = WTf;
    %   首先，预测伪标签   加入到原始规则库中，并进行剩余  未标记样本的 熵值计算  并依次选择进行加入

    for omi_i = 1:size(E_belief_rule,1)    %1-120
        for omi_j = 1:size(E_belief_rule,2)    %  1-13

      omi_example(omi_i,omi_j)  = men(  omi_j , E_belief_rule(omi_i,omi_j)   ) ;       %  先将所有 数值调用出来

        end        %  提取规则代表的样本值
    end

    num_of_get = 0;  %初始化值为0
    
    while num_of_get<10         %  停止条件的标准。   可以重新设置迭代条件
        clear Zong_Shang_A  Ac_shang;  %每次循环结束，清空一次
 
        for oci_i  =  1:size(E_belief_rule,1)

            D_Q_sample_1  =  [ 0,omi_example(oci_i,:)];
            [ ~, ~,  pre_tag_arry(:,:,oci_i) ]  = ER_Data_Driven(AA_AC, D_Q_sample_1,men,sigmaf,WTf_AC,Ini_e,top_k);  %预测标签

            % 将标签预测出来后，进行添加到原始规则库中   ****构成临时规则库

            AA_AC_L  =  [AA_AC ; E_belief_rule(oci_i,:)  ];    %  进行临时更新规则库。
            WTf_AC_L (:,:,size(WTf_AC,3)+1) = pre_tag_arry(:,:,oci_i) ;  %    临时应用的规则结论部分

            omi_example_L  =  omi_example;
            omi_example_L(oci_i,:)  =  [];

            for u_k = 1:size(omi_example_L,1)

                sam_ple_Shang_one  =  omi_example_L(u_k,:);
                sam_ple_Shang_one_1 = [0,sam_ple_Shang_one] ;
                [ ~, ~,  Shang_L_tag_arry ] = ER_Data_Driven(AA_AC_L, sam_ple_Shang_one_1,men,sigmaf,WTf_AC_L,Ini_e,top_k); %预测标签

                Arry_Lin = Shang_L_tag_arry(:,2);
                Arry_Lin( find(Arry_Lin==0) )=[];  % 等于 0 的删去
                
                if size( Arry_Lin,1 ) == 0
                   continue 
                end

                for Ac_kn2  =  1:size( Arry_Lin,1 )
                    Arry_Lin(Ac_kn2) = Arry_Lin(Ac_kn2)*log2(Arry_Lin(Ac_kn2));                  %  求熵
                end
                Ac_shang(u_k) = -( sum( Arry_Lin(1:size(Arry_Lin,1)) ) );    % ---报错   原因：  矩阵  Arry_Lin  有可能全为零--0329

            end
            
            format long
            Zong_Shang_A(oci_i) = sum(Ac_shang);     %  相互之间有差别，但是，差别很小，不是完全一样，

        end

        [~,XZ_index_1] = min(Zong_Shang_A);   %  找到能使熵最小的样本

        %% 进行引入专家知识
        D_Q_sample_1  =  [ 0,omi_example(XZ_index_1,:)];
        [ ~, pre_tag_hard, ~ ] = ER_Data_Driven(AA_AC, D_Q_sample_1,men,sigmaf,WTf_AC,Ini_e,top_k);  %预测标签    pre_tag_hard

        hard_tar_L  =  E_Wt(:,:,XZ_index_1);
        hard_tar_L(  size(hard_tar_L,1),:   )   =   [];   %删除最后一行，置信框架
        [~,in_hard]  =  max (  hard_tar_L(:,2) );   %  挑出了最初始的硬标签！！！！0329

        AA_AC = [AA_AC; E_belief_rule(XZ_index_1,:) ];    %   更新的规则前提  
        WTf_AC(:,:,size(WTf_AC,3)+1)  =  E_Wt(:,:,XZ_index_1); %  更新规则结论部分。  

        
        %     选出来标注后，进行删除原来的
         T_JD  =  [ in_hard , omi_example( XZ_index_1 , : )    ];  %  ------------===-=-=-=-=-=-=-=-=-=-=
        NeedData(  size(NeedData,1)+1,:)  =  T_JD;
         
        E_belief_rule(XZ_index_1,:)  =  [];
        E_Wt(:,:,XZ_index_1)   =   [];
        omi_example( XZ_index_1 , : )  =  [] ;
        
        [aaa,~,~]=ER_Data_Driven(AA_AC,Test_Data,men,sigmaf,WTf_AC,Ini_e,top_k);    %   返回值为精度与预测值
        disp(aaa);
        
        num_of_get  =  num_of_get+1;    %   计数循环次数------
        AC_PRO(num_of_get)  =  aaa ;

        
     end    %   while 循环结束

    
EXPERT_DRIVEN_RULE  =  AA_AC(size(AA,1)+1:size(AA_AC,1),:);     %  调取专家驱动规则
expert_driven_wt    =  WTf_AC(:,:,size(AA,1)+1:size(AA_AC,1));    %  专家知识部分结论


end