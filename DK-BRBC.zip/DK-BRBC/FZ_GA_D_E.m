

%%  利用遗传算法对置信规则库进行融合

function [result] = FZ_GA_D_E(NeedData,AA_AC,men,sigmaf,Ini_e,top_k,WTf_AC,Test_Data,DATA_DRIVEN_RULE,data_driven_wt,EXPERT_DRIVEN_RULE,expert_driven_wt,FF)

%%   2022---五

%   新的遗传算法部分   2022.1.6   

% 用遗传算法对转化后的专家知识进行优化

%    ******前提选择与规则选择同时进行*******    7.28修改
                                         
                                             
         
%      WTf_AC = WTf;

     time1 = clock;
     GA_Data  =  NeedData;
%      GA_Data  =  Train_dat5;
%      GFES   =  AA_AC;            %读取映射过来的规则前提
     GFESQ  =  AA_AC;       %读取规则前提部分
     num=200;                   %设置初始种群数。
     pc=0.8;                    %设置交叉概率
     pm=0.01;                   %设置变异概率

     
     w_ac=0.6  ;                %设置准确性权重
     w_in=0.4  ;                %设置可解释性权重  
     sum_max = size(GFESQ,1)*size(GFESQ,2);
%% 生成初始种群，是一个三维的0-1矩阵
for i=1:num
    ZQ(:,:,i)=round(rand(size(GFESQ,1),size(GFESQ,2)+1));      
end
% WQ=rand(num,size(GFES,1));   %生成数目为num个的规则库的规则权重，(暂时不动)----

for de=1:100                                         %设置迭代次数-------可变

 for be=1:num
     clear TT_L;
     FGS(:,:,be)  =  ZQ(:,1:FF,be).*GFESQ;                         %  此步骤只是对前提进行了选择，下一步对规则进行选择。
     FGS(:,:,be)  =  ZQ(:,FF+1,be).*FGS(:,:,be);                   %  对规则进行选择   也得再乘一下结论部分
     TT_L  =  FGS(:,:,be);
     for h_f = 1 :size(GFESQ,1)
     FGS_wt(:,:,h_f)  =  ZQ(h_f,FF+1,be).* WTf_AC(:,:,h_f)  ;      %  结论部分
     end

     in_zero  =  find(ZQ(:,FF+1,be)==0);
     TT_L(in_zero,:)  =  [];
     FGS_wt(:,:,in_zero)  =  [];

    [ac_1, ~,  ~ ]= ER_Data_Driven(TT_L, GA_Data,men,sigmaf,FGS_wt,Ini_e,top_k);  %预测标签 (不光考虑准确率，还要考虑规则库的紧凑)-=-=-=
    num_sum =   sum(  sum(  ZQ(:,1:FF,be)  )  );

    fit1(be)=ac_1*w_ac - (num_sum/sum_max)*w_in;         %  相加的两项不是一个数量级，应该变成同一数量级。
 end
 
 for oo=1:num
     prob(oo)  =  fit1(oo)/(sum(fit1));
 end                        %下一步：对适应度进行评估，选择，交叉变异
 
 %% 轮盘生成
pk(1)  =  prob(1);                     
for uu  =  2:num
    pk(uu)  =  pk(uu-1)+prob(uu);
end

%%
XZ  =  rand(1,num);   %随机生成数，依据适应度进行种群选择
for bn = 1:num
    for bb = num:-1:1
       if XZ(bn)<pk(bb)
           XGT(:,:,bn) = ZQ(:,:,bb);
       end
    end
end               %XGT新个体--为选择的新个体

 

%% 重点考虑，如何交叉与变异
for kk = 1:num/2
    for jo = 1:size(GFESQ,1)
    cca = rand;
    if cca<pc             %满足条件，进行交叉操作

        cpoint = round(rand(1,1)*(size(GFESQ,2)-1));  %随机选择交叉点
        XGT1(jo,:,kk) = [XGT(jo,1:cpoint,kk),XGT(jo,cpoint+1:size(GFESQ,2)+1,kk+num/2)];
        XGT1(jo,:,kk+num/2) = [XGT(jo,1:cpoint,kk+num/2),XGT(jo,cpoint+1:size(GFESQ,2)+1,kk)];
    else
        XGT1(jo,:,kk) = XGT(jo,:,kk);
        XGT1(jo,:,kk+num/2) = XGT(jo,:,kk+num/2);
    end
    end
    
    end
    
end                              %交叉操作完成，进行变异

%%
for cm = 1:num
    for jo = 1:size(GFESQ,1)
        ccm = rand;
        cmpoint = randperm(size(GFESQ,2),1);  %随机选择变异点
        if ccm<pm
            XGT2(jo,:,cm) = XGT1(jo,:,cm);    %首先将其赋给新个体
            if XGT2(jo,cmpoint,cm)==0       %等于0，变异成1,1变异成0
                XGT2(jo,cmpoint,cm) = 1;
            else
                XGT2(jo,cmpoint,cm) = 0;
            end
        else
                XGT2(jo,:,cm) = XGT1(jo,:,cm);
        end
        % 后半部分选择变异
        if ccm<pm
            if XGT2(jo,FF+1,cm)==0
                XGT2(jo,FF+1,cm) = 1;
            else
                XGT2(jo,FF+1,cm) = 0;
            end
        end
    end                
       %变异操作完成
    ZQ = XGT2;
end           %迭代完成后，再对ZQ进行一次评估

 for be=1:num
     
     clear TT_L;
     FGS(:,:,be)  =  ZQ(:,1:FF,be).*GFESQ;                         %此步骤只是对前提进行了选择，下一步对规则进行选择。
     FGS(:,:,be)  =  ZQ(:,FF+1,be).*FGS(:,:,be);                                                          %对规则进行选择   也得再乘一下结论部分
     TT_L  =  FGS(:,:,be);
     
     for h_f = 1 :size(GFESQ,1)
         FGS_wt(:,:,h_f)  =  ZQ(h_f,FF+1,be).* WTf_AC(:,:,h_f)  ;    %  结论部分
     end
     
     in_zero  =  find(ZQ(:,FF+1,be)==0);
     TT_L(in_zero,:)  =  [];
     FGS_wt(:,:,in_zero)  =  [];

     
     %%  修改部分 
     [ac_1, ~,  ~ ]= ER_Data_Driven(TT_L, GA_Data,men,sigmaf,FGS_wt,Ini_e,top_k);  %预测标签 (不光考虑准确率，还要考虑规则库的紧凑)-=-=-=
     num_sum =   sum(  sum(  ZQ(:,1:FF,be)  )  );
     fit1(be)=ac_1*w_ac - (num_sum/sum_max)*w_in;         %  相加的两项不是一个数量级，应该变成同一数量级。

     %%
     
 end                                                 
        
         [val_xunlianji,val_index]  =  max(fit1) ;
               disp(val_xunlianji);
               
         be  =  val_index;
         clear TT_L;
         FGS(:,:,be)  =  ZQ(:,1:FF,be).*GFESQ;                         %  此步骤只是对前提进行了选择，下一步对规则进行选择。
         FGS(:,:,be)  =  ZQ(:,FF+1,be).*FGS(:,:,be);                   %  对规则进行选择   也得再乘一下结论部分
         TT_L  =  FGS(:,:,be);

         for h_f = 1 :size(GFESQ,1)
             FGS_wt(:,:,h_f)  =  ZQ(h_f,FF+1,be).* WTf_AC(:,:,h_f)  ;    %  结论部分
         end
            
         in_zero  =  find(ZQ(:,FF+1,be)==0);   %  新
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                 in_zero  =  find(ZQ(:,FF+1,be)==0);
         TT_L(in_zero,:)  =  [];
         FGS_wt(:,:,in_zero)  =  [];
         [ac_f, ~,  ~ ]= ER_Data_Driven(TT_L, Test_Data,men,sigmaf,FGS_wt,Ini_e,top_k);  %预测标签
         num_sum =   sum(  sum(  ZQ(:,1:FF,be)  )  );
         Zhan_Bi = num_sum/sum_max   ;    %  评价占比;
         
         disp(Zhan_Bi);
         disp(ac_f)

time2 = clock;
run_time = etime(time2,time1) ;
num_of_YangBen = size(NeedData,1) ;

%    -----结束-----

disp(run_time)
disp(num_of_YangBen)



[ac_data, ~,  ~ ]= ER_Data_Driven(DATA_DRIVEN_RULE, Test_Data,men,sigmaf,data_driven_wt,Ini_e,top_k);  %预测标签   数据
[ac_expert, ~,  ~ ]= ER_Data_Driven(EXPERT_DRIVEN_RULE, Test_Data,men,sigmaf,expert_driven_wt,Ini_e,top_k);  %预测标签   专家
% disp(ac_data)
disp(ac_expert)

result = [ac_data,ac_expert,ac_f];

end