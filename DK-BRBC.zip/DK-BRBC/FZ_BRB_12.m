
%%  封装函数，对初始原型规则前提学习


function [Store_Data,Wp,cnt,Ini_e,A,FF,sigma,KK,NeedData]=FZ_BRB_12(TRAIN_X,TEST_X)

% 2022.06.10
%%   新思路从这开始  12.27   首先训练数据   剩余的作为备选专家知识  
%% 此代码应该第一列为标签，
% clc
% clearvars -except Test_dat1 Train_dat1 Test_dat2 Train_dat2 Test_dat3 Train_dat3 Test_dat4 Train_dat4 Test_dat5 Train_dat5 ONE ONE1


ONE = TRAIN_X ;          %     大规模实验的时候，可以直接进行输入 

b_ = unique (ONE(:,1));         %   取集合a的不重复元素构成的向量
n_class = size(b_,1);           %   读取数据集类别个数

%% 比例设置
BiLi = 0.2 ;

Ini_e  =  zeros(  n_class+1, n_class+2  );
K_class  =  linspace(1 , n_class+1,  n_class+1  );
Ini_e(:,1)  =    K_class' ;

%%  数据集设置


   KK         =   ONE;      %  1 2  10% 3
   Test_Data  =   TEST_X ;                %  测试样本集
   

%%   流式数据集  使用

%      NeedData_index  =  randi ( [ 1 , size(KK,1) ] ,  ceil( size(KK,1)*BiLi ) , 1    );  %  在某一范围内  随机抽取数值    【有可能会抽到同一个样本】

      NeedData_index  =  randi ( [ 1 , size(KK,1) ] ,  ceil( size(KK,1)*BiLi ) , 1    );  %  在某一范围内  随机抽取数值    【有可能会抽到同一个样本】
      NeedData  =  KK(NeedData_index , :);                          %  数据学习部分
      KK(NeedData_index,:)  =  [];                              % 留给专家的数据  删除被数据拿走的
%% 
         %   AQ = KK;
          AQ = NeedData;
          A = AQ;              %   标签在第一列,  此时的A为全部训练数据
          

%%  参数设置
FF = size(A,2)-1 ;                                                               %所输入数据集的特征数。-根据数据集改变
disp(FF)
epsilon=0.75;                                                              %设置初始阈值参数---------[重新考虑，该如何进行设置，]
sigma0 = 1 ;                                                                 %设置初始标准差-----------暂时定为

%%        生成初始标准差


%%  下面这部分基本不再改变

  
%  第一列为标签
p=A(1,1:FF+1);
Wp(1,:)=p(1,2:FF+1);                                                       %构建第一条规则的前提部分
cnt(1)=1;                                                                  %第一条规则包含的样本数量设置为1
sigma(1,:)=ones([1,FF])*sigma0;                                            %标准差设置为初始标准差

Store_Data(1,1)=1;    %存储矩阵中存入第一个样本的位置
for m=2:size(A,1)                                                          %训练样本个数  ，从第二个样本开始    
        p=A(m,1:FF+1);      
   for l=1:size(Wp,1)                                                      %遍历每一条规则
    for j=1:FF                                                             %遍历每一个维度
        K(j)=sigma(l,j);                                                   %将每个维度上的标准差调用出来，为了之后求均值用 
        W(j)=(Wp(l,j)-p(j+1))^2;                                           %欧式距离
    end
    B(l)=sqrt(sum(W))^2;                                                   %求和  开更号，  再平方
    U(l)=(sum(K))/FF;                                                      % 标准差求均值
    M(l)=exp((-B(l)/(2*U(l)^2)));                                          % 计算对规则l的隶属度
   end
      M = M.^(1/FF);                                                                                                     %   2022.06.16   更改

    [max_M,index]=max(M,[],2);                                             %问题：若是类二的数据属于节点一的隶属度更大，那么永远归结到类别二了
    index_ep=find(M>epsilon);                                              %找出大于阈值的所有标签
                                                                           %找出小于0.97
%      g=size(p);                                                            %判断有无标签
%   if g(1,2)==FF+1                                                          %有标签的情况
    if size(index_ep,2)>0
        for h=1:size(index_ep,2)
            %原本是只更新最大那一个，现在改变为挑出大于阈值的
            %到该粗划分的规则中【原：判断标签是否相等】
            cnt( index_ep(h) )  =  cnt(index_ep(h))+1;                                         %有标签且更新节点参数
            qa=1-(1/cnt(index_ep(h)));
            for k=1:FF
                Wp(index_ep(h),k)=(Wp(index_ep(h),k)*(cnt(index_ep(h))-1)+p(k+1))/(cnt(index_ep(h)));      %sigma更新会依赖于输入样本的顺序
                qb  =  (  sigma(index_ep(h),k)-p(k+1)  )^2;
                sigma(index_ep(h),k)   =   sqrt(qa*((sigma(index_ep(h),k)^2))+(qb/cnt(index_ep(h))));
            end                                                                %更新WP参数

            %需要记录归入到各个节点的样本，矩阵存储数据标号
            sum_GuoDu  =  size(Store_Data(index_ep(h),:),2);
            Store_Data(index_ep(h),sum_GuoDu+1)  =  m;                                    %应该是一个递增的矩阵
        end
    else                        %否则，小于更新，大于时，【之前：标签同，更新，不同，添加】
        %添加一条新的粗划分的规则
        Wp(size(Wp,1)+1,:)  =  p(:,2:FF+1);                                      %有标签，添加节点
        cnt(size(Wp,1)+1)  =  1;
        sigma(size(Wp,1),:)  =  ones([1,FF])*sigma0;
        Store_Data(size(Wp,1),1)  =  m;
    end
end    %   只进行了  粗划分规则的 前提部分学习 

disp('num of wp')
disp(size(Wp,1))
end