%% 5折交叉处理  标签放在第一列
clc,clear
 ONE = load('D:\桌面\数据集\wine.data.txt');
% ONE = load('D:\桌面\数据集\wisconsin.txt');
% ONE(:,1)=ONE(:,1)/2;
%% 处理为统一格式   第一列放标签



ao1=mean(ONE);
ao2=std(ONE);
for k=1:size(ONE,1)
    for n=2:size(ONE,2)
        ONE1(k,n)=(ONE(k,n)-ao1(:,n))/ao2(:,n);
    end
end
ONE1=[ONE(:,1),ONE1(:,2:size(ONE,2))];

nFold = 5; 
[n,p] = size(ONE1);
c_out = cvpartition(n,'k',nFold);

Train_dat1 = ONE1(training(c_out,1),:);
Test_dat1 = ONE1(test(c_out,1),:);   

Train_dat2 = ONE1(training(c_out,2),:);
Test_dat2 = ONE1(test(c_out,2),:);   

Train_dat3 = ONE1(training(c_out,3),:);
Test_dat3 = ONE1(test(c_out,3),:);   

Train_dat4 = ONE1(training(c_out,4),:);
Test_dat4 = ONE1(test(c_out,4),:);   

Train_dat5 = ONE1(training(c_out,5),:);
Test_dat5 = ONE1(test(c_out,5),:);   




TRAIN_dataF{1}=Train_dat1;
TRAIN_dataF{2}=Train_dat2;
TRAIN_dataF{3}=Train_dat3;
TRAIN_dataF{4}=Train_dat4;
TRAIN_dataF{5}=Train_dat5;

TEST_dataF{1}=Test_dat1;
TEST_dataF{2}=Test_dat2;
TEST_dataF{3}=Test_dat3;
TEST_dataF{4}=Test_dat4;
TEST_dataF{5}=Test_dat5;

top_k = 3;  % 设置需要融合的规则数量
for fold = 1:5
    
 [Store_Data,Wp,cnt,Ini_e,A,FF,sigma,KK,NeedData] =  FZ_BRB_12(TRAIN_dataF{fold},TEST_dataF{fold});  %  调用函数进行学习以原型为前提的规则
    
 [AA,men,sigmaf,WTf,Ini_e,top_k,aaa_ZUICHU,Nl,DATA_DRIVEN_RULE,data_driven_wt] = FZ_P2R(top_k,FF,A,Store_Data,Wp,cnt,Ini_e,TEST_dataF{fold}); % 将规则前提进行转换，并学习规则结论
        
 [E_belief_rule,E_Wt] = FZ_candidate_EXPERT(FF,KK,sigma,Wp,WTf,Ini_e,Nl,men)   ;  %  构造候选规则前提
    
 [EXPERT_DRIVEN_RULE ,expert_driven_wt,AA_AC,WTf_AC] = FZ_active_learn_expert( AA,KK,sigmaf,WTf,Ini_e,men,top_k,E_belief_rule,E_Wt,NeedData,TEST_dataF{fold});  % 利用主动学习策略进行学习专家驱动置信规则库 

 %  利用遗传算法对置信规则库进行融合
 [result] = FZ_GA_D_E(NeedData,AA_AC,men,sigmaf,Ini_e,top_k,WTf_AC,TEST_dataF{fold},DATA_DRIVEN_RULE,data_driven_wt,EXPERT_DRIVEN_RULE,expert_driven_wt,FF);
 
 Result(fold,:)=result;
 disp('数据驱动，知识驱动，混合驱动')
 disp(Result)
 
end







