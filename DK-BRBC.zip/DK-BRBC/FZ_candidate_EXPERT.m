

%%  构造 候选规则前提


function [E_belief_rule,E_Wt] = FZ_candidate_EXPERT(FF,KK,sigma,Wp,WTf,Ini_e,Nl,men)




% WTf  是上一步中的最终结果，这一步中将会用到。  其第一列放标签，第二列放置信分布，之后的列是空值 0 。



for m = 1:size(KK,1)                                                          %训练样本个数  ，从第二个样本开始    
        p = KK(m,1:FF+1);      
   for l = 1:size(Wp,1)                                                      %遍历每一条规则
    for j = 1:FF                                                             %遍历每一个维度
        K(j) = sigma(l,j);                                                   %将每个维度上的标准差调用出来，为了之后求均值用 
        W(j) = (Wp(l,j)-p(j+1))^2;                                           %欧式距离
    end
    B(l) = sqrt(sum(W))^2;                                                   %求和  开更号，  再平方
    U(l) = (sum(K))/FF;                                                      % 标准差求均值
    M_1(l) = exp((-B(l)/(2*U(l)^2)));                                          % 计算对规则l的隶属度
   end

    [max_M,index] = max(M_1,[],2);                                             %问题：若是类二的数据属于节点一的隶属度更大，那么永远归结到类别二了
%

    
    for pq = 1:size(WTf,3)    %  将激活度作为折扣算子进行折扣计算
        L_SHI_3(:,:,pq) = WTf(:,:,pq);   %先进行调过来
        L_SHI_3(1:size(WTf,1)-1,2,pq) =  L_SHI_3(1:size(WTf,1)-1,2,pq)*M_1(pq);
        L_SHI_3(size(WTf,1),2,pq)   =  L_SHI_3(size(WTf,1),2,pq)*M_1(pq)+(1-M_1(pq));                
    end
        %  下一步，将结果进行融合，      【可以借鉴分类时候的操作，并考虑分类时的操作是否合理.】
        %% 
        R_he = Ini_e;
        R_he(:,2) = L_SHI_3(:,2,1) ;
        for o = 2: size(L_SHI_3,3)  %   对 L_SHI_3  结果进行融合
            R_he(:,3) = L_SHI_3(:,2,o) ;
            R_he(:,2) = E_BRB(R_he)';
        end
        
       
        val_mem  =  R_he(p(1),2);
        EWT3(:,:,m) = Ini_e;   %  赋初始值
        EWT3(p(1),2,m) = val_mem;
        EWT3(size(Ini_e,1),2,m) = 1-val_mem;     
end

        %%  学习规则 - 先建立初始化的第一条规则
        E_sample = KK(1,:) ;        
        for y=1:size(KK,2)-1      %  一个样本训练一条规则-----下一个样本到来之后，怎么对比与更新。
            for ss = 1:Nl                    % Nl 是标签个数
                cc = E_sample(:,y+1)-men(y,ss);       %    从 y+1 开始是因为第一列是标签列
                dd(1,ss) = abs(cc);
            end
            [min_cc,dex] = min(dd);
            E_belief_rule(1,y) = dex;       %  首条规则学习完毕   接下来开始进入循环   【类似于第一个代码】  学习完成后，还应该计算结论隶属度
        end                        
        E_Wt(:,:,1) =  EWT3(:,:,1);
        
        %%
        for e_p = 2 : size(KK,1)            
            E_sample =  KK(e_p,:);   % 取样本            
            for y=1:size(KK,2)-1      %  一个样本训练一条规则-----下一个样本到来之后，怎么对比与更新。
                for ss=1:Nl                    % Nl 是标签个数
                    cc = E_sample(:,y+1)-men(y,ss);       %    从 y+1 开始是因为第一列是标签列
                    dd(1,ss) = abs(cc);
                end
                [min_cc,dex] = min(dd);
                E_Lin_Shi(:,y) = dex;       %  应该是先存放在一个临时的库中
            end
            
            %%  对比  做减法，找全零   比循环快
            Dui_Bi  =  E_Lin_Shi.*ones(   size(E_belief_rule,1), size(E_belief_rule,2)   )-  E_belief_rule;
            
            misi = sum( abs(Dui_Bi),2 );
            
            index_misi = find(misi==0);  %  找到是否有全零的行  有=0--有相同---索引空间不为零
            
            if size(index_misi ,1)==0   %  没有全零的    有全零的话，也是有且只有一个是全零的。
                E_belief_rule( size(E_belief_rule,1)+1 ,:  ) =   E_Lin_Shi;   %  先添加前提
                %%  再添加结论部分
                E_Wt(:,:,size(E_Wt,3)+1) =  EWT3(:,:,e_p);
                
            else     %% 进行融合结论部分                
                %%  超过 1 的问题点
                index_misi  ;  %  要更新的结论部分的 索引  索引值对应的结论  和  当前样本对应的结论   进行融合
                
               
             
                TT_Y = E_Wt(:,:,index_misi) ;   %  TTY中间商
                TT_Y(:,3) =  EWT3(:,2,e_p);                 
                p_lin_    =    E_BRB(   TT_Y  );            
                E_Wt(:,2,index_misi)  =   p_lin_' ;                                                
            end
        end  % 对所有样本的循环                
        %%  规则学习结束     
%%  置信分布 之和 有超过1的情况  ↓   直接进行将所有的结论进行归一化！

        for r = 1 :size(E_Wt,3)
           r_sum = sum(E_Wt(:,2,r));
           E_Wt(:,2,r) = E_Wt(:,2,r)/r_sum;
        end
        disp('num of rule by EXP')
        disp(size(E_Wt,3))
        
   

end